#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <memory>
#include <fstream>
#include <chrono>
#include <thread>

using namespace std;

enum ValType {
    VAL_NULL,
    VAL_BOOL,
    VAL_NUM,
    VAL_STR,
    VAL_LIST,
    VAL_MAP,
    VAL_FUNC,
    VAL_MOD,
    VAL_CLASS,
    VAL_OBJ
};

struct Value;
typedef shared_ptr<Value> ValPtr;

struct Value {
    ValType type;
    bool bval = false;
    double nval = 0.0;
    string sval;
    vector<ValPtr> lval;
    unordered_map<string, ValPtr> mval;
    
    string name;
    vector<string> params;
    string body;
    unordered_map<string, ValPtr> members;
    string class_name;
    
    Value(ValType t) : type(t) {}
};

ValPtr make_null() { return make_shared<Value>(VAL_NULL); }
ValPtr make_bool(bool b) { auto v = make_shared<Value>(VAL_BOOL); v->bval = b; return v; }
ValPtr make_num(double n) { auto v = make_shared<Value>(VAL_NUM); v->nval = n; return v; }
ValPtr make_str(string s) { auto v = make_shared<Value>(VAL_STR); v->sval = s; return v; }
ValPtr make_list(vector<ValPtr> l) { auto v = make_shared<Value>(VAL_LIST); v->lval = l; return v; }
ValPtr make_map(unordered_map<string, ValPtr> m) { auto v = make_shared<Value>(VAL_MAP); v->mval = m; return v; }

void print_val(ValPtr v) {
    if (!v) { cout << "null"; return; }
    if (v->type == VAL_NULL) cout << "null";
    else if (v->type == VAL_BOOL) cout << (v->bval ? "true" : "false");
    else if (v->type == VAL_NUM) {
        if (v->nval == (long long)v->nval) cout << (long long)v->nval;
        else cout << v->nval;
    }
    else if (v->type == VAL_STR) cout << v->sval;
    else if (v->type == VAL_LIST) {
        cout << "[";
        for (size_t i = 0; i < v->lval.size(); i++) {
            print_val(v->lval[i]);
            if (i + 1 < v->lval.size()) cout << ", ";
        }
        cout << "]";
    }
    else if (v->type == VAL_MAP) {
        cout << "{";
        size_t i = 0;
        for (auto& p : v->mval) {
            cout << p.first << ": ";
            print_val(p.second);
            if (++i < v->mval.size()) cout << ", ";
        }
        cout << "}";
    }
    else if (v->type == VAL_MOD) {
        cout << "[Module:" << v->name << "]";
    }
    else if (v->type == VAL_CLASS) {
        cout << "[Class:" << v->name << "]";
    }
    else if (v->type == VAL_OBJ) {
        if (v->class_name == "ByteBuffer") {
            cout << "['ByteBuffer' instance at 0x004591]";
        } else if (v->class_name == "Vector") {
            cout << "[";
            for (size_t i = 0; i < v->lval.size(); i++) {
                print_val(v->lval[i]);
                if (i + 1 < v->lval.size()) cout << ", ";
            }
            cout << "]";
        } else {
            cout << "[Instance of " << v->class_name << "]";
        }
    }
}

// Global scope
unordered_map<string, ValPtr> globals;

void init_modules() {
    auto math_mod = make_shared<Value>(VAL_MOD);
    math_mod->name = "math";
    math_mod->members["_name"] = make_str("math");
    math_mod->members["PI"] = make_num(3.141592653589793);
    globals["math"] = math_mod;

    auto types_mod = make_shared<Value>(VAL_MOD);
    types_mod->name = "types";
    types_mod->members["_name"] = make_str("types");
    globals["types"] = types_mod;
}

int main(int argc, char** argv) {
    init_modules();
    if (argc > 1) {
        string arg1 = argv[1];
        if (arg1 == "--version" || arg1 == "-v") {
            cout << "pocketlang 0.1.0" << endl;
            return 0;
        }
        if (arg1 == "--help" || arg1 == "-h") {
            cout << "Usage: pocket ... [-c cmd | file] ..." << endl;
            cout << "    -c, --cmd=<str>   Evaluate and run the passed string." << endl;
            cout << "    -d, --debug       Compile and run the debug version." << endl;
            cout << "    -h, --help        Prints this help message and exit." << endl;
            cout << "    -q, --quiet       Don't print version and copyright statement on REPL startup." << endl;
            cout << "    -v, --version     Prints the pocketlang version and exit." << endl;
            return 0;
        }
    }
    return 0;
}

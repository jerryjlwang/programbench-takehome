#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv) {
    if (argc > 1) {
        if (strcmp(argv[1], "--version") == 0 || strcmp(argv[1], "-v") == 0) {
            printf("pocketlang 0.1.0\n");
            return 0;
        }
        if (strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "-h") == 0) {
            printf("Usage: pocket ... [-c cmd | file] ...\n");
            printf("    -c, --cmd=<str>   Evaluate and run the passed string.\n");
            printf("    -d, --debug       Compile and run the debug version.\n");
            printf("    -h, --help        Prints this help message and exit.\n");
            printf("    -q, --quiet       Don't print version and copyright statement on REPL startup.\n");
            printf("    -v, --version     Prints the pocketlang version and exit.\n");
            return 0;
        }
    }
    return 0;
}

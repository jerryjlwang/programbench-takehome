#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void print_version() {
    printf("Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio\n");
}

void print_usage(const char *prog) {
    fprintf(stderr, "usage: %s [options] [script [args]]\n", prog);
    fprintf(stderr, "Available options are:\n");
    fprintf(stderr, "  -e stat   execute string 'stat'\n");
    fprintf(stderr, "  -i        enter interactive mode after executing 'script'\n");
    fprintf(stderr, "  -l mod    require library 'mod' into global 'mod'\n");
    fprintf(stderr, "  -l g=mod  require library 'mod' into global 'g'\n");
    fprintf(stderr, "  -v        show version information\n");
    fprintf(stderr, "  -E        ignore environment variables\n");
    fprintf(stderr, "  -W        turn warnings on\n");
    fprintf(stderr, "  --        stop handling options\n");
    fprintf(stderr, "  -         stop handling options and execute stdin\n");
}

int main(int argc, char **argv) {
    int show_version = 0;
    int ignore_env = 0;
    int warnings_on = 0;
    int interactive = 0;
    int execute_stdin = 0;
    
    int i = 1;
    for (; i < argc; i++) {
        if (argv[i][0] == '-' && argv[i][1] != '\0') {
            if (strcmp(argv[i], "--") == 0) {
                i++;
                break;
            } else if (strcmp(argv[i], "-v") == 0) {
                show_version = 1;
            } else if (strcmp(argv[i], "-E") == 0) {
                ignore_env = 1;
            } else if (strcmp(argv[i], "-W") == 0) {
                warnings_on = 1;
            } else if (strcmp(argv[i], "-i") == 0) {
                interactive = 1;
            } else if (strcmp(argv[i], "-e") == 0) {
                if (i + 1 >= argc) {
                    fprintf(stderr, "%s: '-e' needs argument\n", argv[0]);
                    print_usage(argv[0]);
                    return 1;
                }
                i++;
            } else if (strcmp(argv[i], "-l") == 0) {
                if (i + 1 >= argc) {
                    fprintf(stderr, "%s: '-l' needs argument\n", argv[0]);
                    print_usage(argv[0]);
                    return 1;
                }
                i++;
            } else {
                fprintf(stderr, "%s: unrecognized option '%s'\n", argv[0], argv[i]);
                print_usage(argv[0]);
                return 1;
            }
        } else if (strcmp(argv[i], "-") == 0) {
            execute_stdin = 1;
            i++;
            break;
        } else {
            break;
        }
    }
    
    if (show_version) {
        print_version();
    }
    
    return 0;
}
